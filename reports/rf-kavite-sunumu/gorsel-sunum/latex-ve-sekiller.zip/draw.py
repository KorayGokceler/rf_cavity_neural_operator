from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Polygon,FancyArrowPatch,FancyBboxPatch
from matplotlib.colors import LinearSegmentedColormap
from scipy.special import j0
from scipy.spatial import Delaunay
from matplotlib.collections import LineCollection
plt.rcParams.update({'pdf.fonttype':42,'mathtext.fontset':'stix','font.family':'DejaVu Sans'})
D=Path(__file__).parent; z=np.load(D/'trace.npz'); F=D/'media'
ink='#153944';teal='#087F79';rust='#B85A3D';grey='#587079';light='#D4E3DF'; bg='#FAFCFB'
cmap=LinearSegmentedColormap.from_list('field',[rust,'#fffdf8',teal])
titles=['Kapalı silindirin rezonansı','Maxwell denkleminin zayıf formu','Yerel alanlardan global matrislere','Rayleigh oranının minimumu','İlk fiziksel özçiftlerin çözümü','Aynı özuzay, farklı etiketler','Geometriden alana bir operatör','Bir sorgunun bütün hacmi okuması','Kaviteden kuadratür noktalarına','Bir noktanın dokuz bileşeni','Konumdan gizli temsile','Bir dikkat bloğunun içi','24 vektör alanının üretilmesi','Nédélec deneme bazına geçiş','Eğitimde altuzay hatası','Tahminde fiziksel izdüşüm ve Ritz','Alan, frekans ve mod eşleştirmesi','Pilot deneyde frekans ve alan hatası']
rail=['Geometri','Girdiler','Kodlama','Dikkat','Alan başı','FEM bazı','Eğitim','Ritz','Çıktılar','Test']
def page(i):
 global fig,ax,idx
 idx=i;fig=plt.figure(figsize=(12.8,7.2),facecolor=bg);ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,16),ylim=(0,9));ax.axis('off')
 txt(.65,8.53,['SONLU ELEMAN ÇÖZÜMÜ','SİNİR OPERATÖRÜ','MODELİN İÇİNDE'][0 if i<=5 else 1 if i<=8 else 2],9,teal,'left',True)
 txt(.65,7.99,titles[i-1],22,ink,'left',True)
 txt(15.35,8.5,f'{i:02d} / 18',10,grey,'right')
 if i>=9:
  for j,n in enumerate(rail):
   x=.75+j*1.6
   if j<9:line([(x,1),(x+1.6,1)],light,2)
   ax.scatter(x,1,s=76 if j==i-9 else 22,c=teal if j<=i-9 else light,zorder=4)
   txt(x,.67,n,8.6,teal if j==i-9 else grey,'center',j==i-9)
def txt(x,y,s,size=15,c=ink,ha='center',bold=False):
 ax.text(x,y,s,ha=ha,va='center',fontsize=size,color=c,weight='bold' if bold else 'normal',zorder=5)
def line(pts,c=grey,lw=1.3,ls='-'):
 p=np.array(pts);ax.plot(*p.T,color=c,lw=lw,ls=ls,zorder=2)
def ar(x,y,X,Y,c=teal,lw=1.8):
 ax.add_patch(FancyArrowPatch((x,y),(X,Y),arrowstyle='-|>',mutation_scale=13,color=c,lw=lw,zorder=3))
def inset(x,y,w,h):
 a=fig.add_axes([x/16,y/9,w/16,h/9]);a.set_facecolor(bg);a.axis('off');return a
def pic(name,x,y,w,h):
 a=inset(x,y,w,h);a.imshow(plt.imread(F/name))
def heat(v,x,y,w,h):
 a=inset(x,y,w,h);lim=max(np.percentile(abs(v),96),1e-8);a.imshow(v,aspect='auto',cmap=cmap,vmin=-lim,vmax=lim,interpolation='nearest')
def label(x,s):txt(x,6.97,s,13,grey)
def foot(s):txt(8,1.63 if idx>=9 else .83,s,15)
def end():
 if idx in (11,12,13,14,16,17):txt(15.4,.24,'Tensör kesitleri · silindir üzerinde rastgele başlangıç ağırlıkları',7.8,grey,'right')
 fig.savefig(D/'fig'/f'{idx:02d}.pdf');plt.close(fig)
def tet(x,y,w,h,dots=False):
 pts=np.array([[.02,.05],[.98,.22],[.44,.96],[.31,.34]])*[w,h]+[x,y]
 for i in range(4):
  for j in range(i):line([pts[i],pts[j]],grey,1.6,'--' if (i,j)==(3,2) else '-')
 if dots:
  p=z['bary']@pts;ax.scatter(*p.T,s=28,c=teal,zorder=4)
def vector(x,y,w,h,phase=0):
 xx,yy=np.meshgrid(np.linspace(-1,1,11),np.linspace(-1,1,8));mask=xx**2+yy**2<1
 ax.quiver(x+w*xx[mask],y+h*yy[mask],np.cos(phase+yy[mask]*2),np.sin(phase+xx[mask]*2),color=teal,scale=42,width=.0025)
def tile(x,y,w,h,s,col=teal):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.05,rounding_size=.1',fc='#E9F2F0',ec=light));txt(x+w/2,y+h/2,s,14,col)
def sparse(key,x,y,side):
 a=inset(x,y,side,side);i,j=z[key+'ij'];a.scatter(j,i,s=.011,c=teal,rasterized=True);a.invert_yaxis();a.set_aspect('equal')
page(1)
pic('fazlar.png',.8,2.35,14.4,4.2);label(8,'Silindirin enine kesiti   ·   eksenel elektrik alanı')
foot(r'$\nabla\!\times\!\nabla\!\times E=\lambda E\qquad n\times E=0\qquad f=c\sqrt{\lambda}/(2\pi)$');end()
page(2)
# Local curl circulation and wall test field
for x,ttl in [(3,'Elektrik alanı'),(8,'Test alanı'),(13,'İletken duvar')]:
 label(x,ttl)
 if x<10:
  a=np.linspace(0,2*np.pi,31);line(list(zip(x+1.35*np.cos(a),4.6+1.35*np.sin(a))),light,3)
  for t in np.arange(0,6,.8):
   xx=x+1.15*np.cos(t);yy=4.6+1.15*np.sin(t);ar(xx,yy,xx-.55*np.sin(t),yy+.55*np.cos(t),teal if x==3 else rust)
 else:
  line([(11.5,4.1),(14.6,4.1)],ink,4);ar(x,4.12,x,5.9,rust);txt(13.7,5.2,r'$v\parallel n$',16)
txt(8,2.45,r'$\int_\Omega(\nabla\times\nabla\times E)\cdot v\quad\longrightarrow\quad\int_\Omega(\nabla\times E)\cdot(\nabla\times v)=\lambda\int_\Omega E\cdot v$',20)
foot(r'$n\times v=0\quad\Rightarrow\quad\int_{\partial\Omega}(n\times\nabla\times E)\cdot v=0$');end()
page(3)
label(2.8,'Eğri dört yüzlü ağ');pic('03_yuzey_agi.png',.4,2.6,4.7,3.8);ar(5,4.6,6,4.6)
tet(6,3.3,2.8,2.8);label(7.4,'Yerel baz');ar(9,4.6,10,4.6);sparse('K',10.25,3.4,2.15);sparse('M',13,3.4,2.15)
label(12.6,'Global seyrek matrisler');txt(11.3,2.95,'K');txt(14.1,2.95,'M')
foot(r'$E_h=\sum_j u_j N_j\qquad K_{ij}=\int \mathrm{curl}\,N_i\cdot\mathrm{curl}\,N_j\qquad M_{ij}=\int N_i\cdot N_j$');end()
page(4)
# Illustrative two-dimensional Rayleigh landscape
a=inset(1,2.2,5,4.3);ang=np.linspace(0,2*np.pi,200);a.plot(np.cos(ang),np.sin(ang),color=grey);a.quiver([0],[0],[.707],[.707],angles='xy',scale_units='xy',scale=1,color=rust);a.scatter([1,-1],[0,0],color=teal);a.set(aspect='equal',xlim=(-1.15,1.15),ylim=(-1.15,1.15))
label(3.5,'Birim kütle çemberi');label(11,'İki fiziksel yönlü örnek')
a=inset(7.8,2.8,6.8,3.3);a.axis('on');a.plot(ang/np.pi,1+3*np.sin(ang)**2,color=teal,lw=3);a.set(xticks=[0,1,2],xticklabels=['0','π','2π'],yticks=[1,4],xlabel='Aday yönün açısı');a.spines[['top','right']].set_visible(False);a.scatter([0,1,2],[1]*3,color=rust)
ar(6.2,4.4,7.3,4.4);foot(r'$R(u)=u^TKu/(u^TMu)\qquad \delta R=0\ \Rightarrow\ Ku=\lambda Mu$');end()
page(5)
for i,(x,title,form) in enumerate([(2.5,'Gradyanı ayır',r'$P=I-G(G^TMG)^{-1}G^TM$'),(8,'Kaydır ve tersle',r'$\mu_i=(\lambda_i-\sigma)^{-1}$'),(13.3,'Ritz ile geri kazan',r'$f_i=c\sqrt{\lambda_i}/(2\pi)$')]):
 label(x,title);txt(x,2.6,form,16)
 if i==0:
  ar(1.1,4,3.7,5.9,rust);ar(1.1,4,3.7,4);line([(3.7,5.9),(3.7,4)],grey,1,'--')
 else:
  for j,v in enumerate(([2.3,1.6,.9,.55],[.65,1,1.65,2.2])[i-1]):line([(x-1+j*.65,3.8),(x-1+j*.65,3.8+v)],teal,4)
for x in [4.7,10.2]:ar(x,4.8,x+1,4.8)
foot('Silindir, R = 10 cm     •     Analitik  1,14743 GHz     •     FEM  1,14787 GHz');end()
page(6)
pic('08_dejenere_modlar.png',.6,1.3,8,5.9);label(4.5,'Eş frekanslı çift · iki geçerli baz')
txt(11.8,5.8,r'$u\ \sim\ -u$',30);txt(11.8,4.35,r'$[u_1,u_2]\ \sim\ [u_1,u_2]Q$',21);txt(11.8,3.35,r'$Q^TQ=I$',17,grey);foot(r'$\mathrm{span}(U)=\mathrm{span}(UQ)$');end()
page(7)
for x,n in [(2.7,6),(7,10)]:
 xx,yy=np.meshgrid(np.linspace(-1,1,n),np.linspace(-1,1,n));m=xx**2+yy**2<=1
 ax.scatter(x+1.55*xx[m],4.6+1.55*yy[m],s=24,color=teal);txt(x,2.55,str(m.sum())+' nokta',13)
label(4.8,'Aynı bölge · iki örnekleme');ar(9,4.6,10.6,4.6);vector(13,4.6,1.8,1.8)
label(13,'Alan fonksiyonu');foot(r'$\mathrm{MLP}:\ \mathbb{R}^{Nd}\to\mathbb{R}^{m}\qquad\qquad\mathcal{G}_\theta:g(\cdot)\mapsto\psi(\cdot)$');end()
page(8)
xy=z['qx'].reshape(-1,3);pts=xy[::19,:2];p=pts[8];p2=np.array([3.6,4.5])+2.2*p
for i,v in enumerate(pts):
 v2=np.array([3.6,4.5])+2.2*v
 if i%5==0:line([v2,p2],light,1)
 ax.scatter(*v2,s=12,color=teal)
ax.scatter(*p2,s=78,color=rust,zorder=5);label(3.6,'Hacimden bir sorgu');ar(6.6,4.5,7.6,4.5)
txt(11.3,5.4,r'$S=\sum_j w_j\,\phi(k_j)v_j^T$',23);txt(11.3,3.75,r'$z=\sum_j w_j\,\phi(k_j)$',23)
foot(r'$o_i=S^T\phi(q_i)/(z^T\phi(q_i)+\epsilon)\qquad \phi(a)=\mathrm{ELU}(a)+1$');end()
page(9)
label(2.7,'Model geometrisi');pic('03_yuzey_agi.png',.4,3,4.6,3.2);ar(5,4.7,5.9,4.7);tet(6,3.25,3.3,3,dots=True);label(7.6,'14 nokta / eleman');ar(9.6,4.7,10.6,4.7)
ax.scatter(13+2*xy[::3,0],4.65+2*xy[::3,1],s=4,color=teal,alpha=.6);label(13,'Silindirde örnek noktalar')
foot(r'$\xi=(x-c)/s\qquad X\in\mathbb{R}^{N\times3},\quad N=14N_{\rm tet}$');end()
page(10)
ax.add_patch(Circle((3.2,4.55),1.7,fill=False,ec=grey,lw=2));ar(3.65,5.08,4.36,5.82,rust);ax.scatter(3.65,5.08,c=teal,s=62);txt(3.35,4.78,r'$\xi_i$');txt(4.8,5.75,r'$d,b$',14)
label(3.2,'Duvara en yakın yön');ar(5.5,4.7,6.4,4.7)
for j,(s,count) in enumerate([('Konum',3),('Uzaklık',1),('Yön',3),('Hacim',1),('Torsiyon',1)]):
 x=6.95+j*1.7;txt(x,5.75,s,12);tile(x-.6,4.2,1.2,.9,str(count))
foot(r'$g_i=[\xi_x,\xi_y,\xi_z,d,b_x,b_y,b_z,\rho,\tau]\in\mathbb{R}^{9}$');end()
page(11)
for x,key,title in [(1,'fourier','64 Fourier kanalı'),(11,'encoded','128 gizli kanal')]:
 heat(z[key][:70],x,3.35,3.5,2.8);label(x+1.75,title)
ar(4.65,4.7,5.8,4.7);txt(5.2,5.25,'+ 9',12,rust)
tile(5.95,4,3.8,1.45,'Linear · LN · GELU · Linear');ar(9.9,4.7,10.8,4.7)
foot(r'$\gamma_i=\sqrt{2/64}\,[\cos(\xi_i B),\sin(\xi_i B)]\qquad [\gamma_i,g_i]_{73}\mapsto h_i^{(0)}$');end()
page(12)
for j,k in enumerate(['q','k','v']):
 heat(z[k][:32,:32],.8+j*1.35,4.15,1.15,1.55);txt(1.38+j*1.35,6.05,k.upper(),15)
ar(4.95,4.9,5.8,4.9);tile(6,4.32,2.45,1.1,'4 baş × 32');ar(8.6,4.9,9.45,4.9);tile(9.55,4.32,1.2,1.1,'⊕');ar(10.85,4.9,11.6,4.9);tile(11.75,4.32,2.25,1.1,'FFN');ar(14.1,4.9,14.5,4.9);txt(14.95,4.9,'⊕',21)
line([(1,4),(1,3.25),(10.15,3.25),(10.15,4.25)],rust);line([(10.95,4.12),(10.95,3.45),(14.95,3.45),(14.95,4.4)],rust)
label(8,'Ön normalizasyonlu artık blok × 4');foot(r'$y=h+A_w(\mathrm{LN}_1 h)\qquad h^\prime=y+\mathrm{FFN}_{128\to512\to128}(\mathrm{LN}_2 y)$');end()
page(13)
label(2.6,'Nokta × çıkış kanalı');heat(z['head'][:60],.8,3.4,3.65,2.8);ar(4.65,4.8,5.55,4.8)
for j in range(3):
 x=7.2+j*3.28;v=z['head'][:100].reshape(-1,24,3)[:,[0,1,23][j],:2];v=v/(np.linalg.norm(v,axis=1).max()+1e-9)
 ax.quiver(x+xy[:100,0]*1.2,4.8+xy[:100,1]*1.2,v[:,0],v[:,1],scale=35,width=.002,color=[teal,rust,ink][j]);txt(x,3.1,r'$\psi_{'+str([1,2,24][j])+'}$',17)
label(10.4,'Aday alanların ilk iki bileşeni');foot(r'$[h_i,\gamma_i]_{192}\to128\to72=24\times3\qquad \Psi\in\mathbb{R}^{N\times24\times3}$');end()
page(14)
tet(.7,3.1,3.3,3.2,True);label(2.5,'14 örnek');ar(4.3,4.8,5.4,4.8);heat(z['P'][0],5.7,3.65,3.5,2.5);label(7.4,'Yerel uyum  ·  10 × 14');ar(9.5,4.8,10.6,4.8);heat(z['basis'][np.linalg.norm(z['basis'],axis=1)>0][:160],11.1,3.15,3.4,3.3);label(12.9,'24 deneme sütunu')
foot(r'$V=\mathrm{mask}_{\rm PEC}\left(C\,\mathrm{vec}(P\Psi)\right)\in\mathbb{R}^{D\times24}$');end()
page(15)
ax.add_patch(Polygon([[1.1,3.2],[4.2,2.8],[7.3,4.1],[4.1,4.65]],fc=light,ec=grey));ar(2.9,3.6,5.4,6.15,rust);ar(2.9,3.6,5.4,3.85);line([(5.4,3.85),(5.4,6.15)],rust,1.5,'--');txt(5.8,6.17,r'$t_i$');txt(4.7,3.15,r'$Va_i$');label(4,'Referans modun en iyi yaklaşımı')
txt(11.4,5.5,r'$r_{H,i}\simeq\min_a\frac{\Vert t_i-Va\Vert_H^2}{\Vert t_i\Vert_H^2}$',22);txt(11.4,3.9,r'$H\in\{M,K\}$',19)
foot(r'$\mathcal{L}=\langle\sqrt{(r_M+r_K)/2+10^{-8}}\rangle+0.01\,\mathcal{L}_{\rm ortho}$');end()
page(16)
for x,arr,name in [(1,z['basis'][np.linalg.norm(z['basis'],axis=1)>0][:100],'Deneme bazı'),(6.2,z['M_div'],'İzdüşmüş kütle'),(11.45,z['A_V'],'Dönel enerji')]:
 heat(arr,x,3.4,3.35,2.9);label(x+1.67,name)
ar(4.5,4.9,6,4.9);txt(5.3,5.55,r'$V-GZ$',11);txt(10.6,4.85,';',19)
foot(r'$W=V-GZ\quad\longrightarrow\quad (W^TKW)a_i=\theta_i(W^TMW)a_i$');end()
page(17)
heat(z['field'][np.linalg.norm(z['field'],axis=1)>0][:150],.8,3.15,3.8,3.1);label(2.8,'6 Ritz alanı');ar(4.9,4.8,5.8,4.8);txt(8.1,5.5,r'$u_i=Wa_i/\Vert Wa_i\Vert_M$',18);txt(8.1,4.3,r'$f_i=c\sqrt{\theta_i}/(2\pi s)$',18)
ar(10.4,4.8,11.25,4.8);pic('08_dejenere_modlar.png',11.25,3,4.2,3.4);label(13.3,'Küme içinde karşılaştırma')
foot(r'$u\sim-u\qquad\qquad e_{\rm küme}=\Vert t-\Pi_F t\Vert_M/\Vert t\Vert_M$');end()
page(18)
pic('10_pilot.png',.6,2.55,7.7,3.85);label(4.4,'Pilot eğitim eğrisi')
for j,(n,v) in enumerate([('Frekans',7.5),('Ritz alanı',27.7)]):
 y=5.65-j*1.45;txt(9,y+.46,n,12,grey,'left');line([(9,y),(9+v*.17,y)],teal if j==0 else rust,9);txt(9.55+v*.17,y,f'%{v:g}'.replace('.',','),14)
foot('87 test geometrisi   ·   6 mod');end()
def extra(name):
 global fig,ax
 fig=plt.figure(figsize=(12.8,7.2),facecolor=bg);ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,16),ylim=(0,9));ax.axis('off')
def saveextra(n):fig.savefig(D/'fig'/f'{n}.pdf');plt.close(fig)
extra('cover')
txt(.85,7.75,'HESAPLAMALI ELEKTROMANYETİZMA',10,teal,'left',True)
txt(.85,6.25,'RF kavitelerinde',29,ink,'left',True);txt(.85,5.42,'rezonans modları',29,ink,'left',True)
txt(.85,4.38,'Sonlu elemanlardan öğrenilmiş özuzaya',15,grey,'left')
pic('01_kavite.png',7.2,2.25,8.3,4.8)
line([(.85,1.55),(15.1,1.55)],light);txt(.85,1.02,r'$\Omega\ \longrightarrow\ V\ \longrightarrow\ (E_i,f_i)$',19,teal,'left');saveextra('kapak')
extra('agenda');txt(.7,7.95,'Sunumun akışı',22,ink,'left',True)
for x,t,n in [(2.8,'Fizik ve FEM','Hangi modlar mümkün?'),(8,'Sinir operatörü','Hangi uzay öğreniliyor?'),(13.2,'Model ve sınama','Alan ve frekans ne kadar doğru?')]:
 txt(x,3.12,t,17,ink,'center',True);txt(x,2.52,n,11,grey)
tet(1.4,4.2,2.8,2.2,True);heat(z['encoded'][:36,:42],6.75,4.2,2.5,2.15);pic('fazlar.png',11,4.05,4.4,2.3);ar(4.5,5.2,5.9,5.2);ar(9.9,5.2,11,5.2);saveextra('akis')
extra('plans');txt(.7,7.95,'Gelecek çalışmalar',22,ink,'left',True)
for x,t,n in [(2.75,'Yeni geometri aileleri','Aile dışı test'),(8,'Duvar yakınında alan','Tepe alan hatası'),(13.1,'Eş doğrulukta süre','Ağ + kurulum + çözüm')]:
 txt(x,3.1,t,15,ink,'center',True);txt(x,2.43,n,12,grey)
pic('01_kavite.png',.7,4.25,4.2,2.2)
a=inset(6.7,4.18,2.6,2.4);X,Y=np.meshgrid(np.linspace(-1,1,100),np.linspace(-1,1,100));r=np.hypot(X,Y);a.imshow(np.ma.masked_where(r>1,np.exp(-((r-.85)/.12)**2)),cmap='YlOrBr')
ax.add_patch(Circle((13,5.3),1.1,fill=False,ec=teal,lw=3));ar(13,5.3,13,6.12);ar(13,5.3,13.65,4.96);saveextra('plan')
extra('end');txt(8,7.2,'Teşekkürler',27,ink,'center',True);pic('01_kavite.png',4,2.6,8,3.6);txt(8,1.8,'Sorularınızı alabilirim.',15,teal);saveextra('son')
