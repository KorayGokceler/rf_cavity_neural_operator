"""Trace the configured field3d model on a small PEC cylinder; no training."""
import json
from pathlib import Path
import torch
import yaml
from netgen.occ import Axes, Cylinder, OCCGeometry, Z
from ngsolve import Mesh
from src.data.field_dataset import field_collate, field_item
from src.data_gen.highorder import field_operators
from src.models.eigenspace_operator_field import EigenspaceOperatorField

conf = yaml.safe_load(Path('configs/field_3d_noproj.yaml').read_text())['model']
args = {k: conf[k] for k in ('embed_dim','n_heads','n_basis','num_field_modes','rff_dim','rff_length_scale','dropout')}
torch.manual_seed(0)
m = EigenspaceOperatorField(val_dim=9, **args, **conf['eigenspace']).eval()
m.freq_stats = {'mean': 0., 'std': 1.}  # Dummy statistics for a shape check only.
geo = Cylinder(Axes((0, 0, 0), Z), r=.1, h=.1)
geo.faces.name = 'wall'
mesh = Mesh(OCCGeometry(geo).GenerateMesh(maxh=.075))
mesh.Curve(2)
ops = field_operators(mesh)
batch = field_collate([field_item(ops)])

import numpy as np
data = {}
def capture(key):
    def hook(module, args, out):
        data[key] = out.detach().flatten(0,-2).numpy()[:160].copy()
    return hook
for key,layer in [('fourier',m.rff),('encoded',m.encoder),('q',m.blocks[0].attn.q_proj),('k',m.blocks[0].attn.k_proj),('v',m.blocks[0].attn.v_proj),('head',m.edge_head)]:
    layer.register_forward_hook(capture(key))
with torch.inference_mode():
    res=m(batch)
for key in ['basis','field','Z','M_div','A_V']:
    data[key]=res[key][0].detach().numpy()
for key in ['qx','qfeat','bary','X','tets','P']:
    data[key]=ops[key]
for key in ['M','K']:
    rows,cols=ops[key].nonzero()
    data[key+'ij']=np.array([rows,cols])
np.savez_compressed(Path(__file__).with_name('trace.npz'),**data)
