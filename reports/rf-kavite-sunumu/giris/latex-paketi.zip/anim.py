from pathlib import Path
import numpy as np
from scipy.special import j0
from PIL import Image, ImageDraw, ImageFont
from matplotlib import colormaps
root=Path(__file__).parent
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
small=ImageFont.truetype(font,19)
large=ImageFont.truetype(font,26)
def frame(phase):
    y,x=np.mgrid[-1:1:310j,-1:1:310j]
    r=np.hypot(x,y)
    amp=np.cos(2*np.pi*phase)
    colors=(colormaps['RdBu_r']((1+j0(2.4048255577*r)*amp)/2)[:,:,:3]*255).astype('uint8')
    colors[r>1]=255
    img=Image.new('RGB',(820,433),'white')
    img.paste(Image.fromarray(colors),(30,72))
    d=ImageDraw.Draw(img)
    d.ellipse((30,72,339,381),outline='#294653',width=3)
    d.text((30,16),'Metal silindirin enine kesiti',font=large,fill='#183c4a')
    d.text((399,75),'Merkezdeki elektrik alanı',font=large,fill='#183c4a')
    X=np.linspace(421,779,180);Y=206-65*np.cos(np.linspace(0,2*np.pi,180))
    d.line((421,206,779,206),fill='#77868a',width=1)
    d.line(list(zip(X,Y)),fill='#286575',width=3)
    px=421+358*phase;py=206-65*amp
    d.ellipse((px-6,py-6,px+6,py+6),fill='#172f3b')
    d.text((414,282),'0',font=small,fill='black');d.text((689,282),'1 periyot',font=small,fill='black')
    d.text((401,338),'Kırmızı  +z       Mavi  −z',font=small,fill='#183c4a')
    d.text((30,399),'Beyaz: eksenel alan sıfır. Zaman yavaşlatılmıştır.',font=small,fill='#405867')
    return img
frames=[frame(i/48) for i in range(48)]
frames[0].save(root/'rezonans.gif',save_all=True,append_images=frames[1:],duration=85,loop=0)
strip=Image.new('RGB',(930,348),'white');d=ImageDraw.Draw(strip)
for i,p in enumerate([0,.25,.5]):
    strip.paste(frame(p).crop((29,71,341,383)).resize((276,276)),(17+i*310,4))
    d.text((60+i*310,296),['Başlangıç  (+z)','Çeyrek tur  (0)','Yarım tur  (−z)'][i],font=small,fill='#173747')
strip.save(root/'figures/fazlar.png')
