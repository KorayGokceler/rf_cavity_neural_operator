"""Vector artwork for the RF cavity eigenspace operator. Run with numpy, matplotlib."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, FancyArrowPatch, Polygon, Circle
from matplotlib.collections import PolyCollection
plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'stix','pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'rf-eigenspace-v1','axes.unicode_minus':True})
D=Path(__file__).resolve().parent
W,H=180,140
navy='#163344';txt='#193644';teal='#006F70';teal2='#328888';warm='#934821';gray='#506674';line='#9EAFB6';pale='#E4F2F0';sand='#FBF4EA'
def render(lang):
    def L(en,tr):return en if lang=='en' else tr
    fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
    ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,W),ylim=(H,0),aspect='equal');ax.axis('off')
    def t(x,y,s,size=8,c=txt,ha='left',bold=False):
        return ax.text(x,y,s,fontsize=size,color=c,ha=ha,va='center',fontweight='bold' if bold else 'normal',zorder=8,linespacing=1.17)
    def ln(p,c=line,lw=.75,ls='-',z=3):
        a=np.array(p);ax.plot(a[:,0],a[:,1],color=c,lw=lw,ls=ls,solid_joinstyle='round',solid_capstyle='round',zorder=z)
    def arrow(x,y,xx,yy,c=navy,lw=.95,ms=8):
        ax.add_patch(FancyArrowPatch((x,y),(xx,yy),arrowstyle='-|>',color=c,lw=lw,mutation_scale=ms,shrinkA=0,shrinkB=0,zorder=5))
    def rect(x,y,w,h,fc,ec='none',lw=.7,r=.9):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',facecolor=fc,edgecolor=ec,lw=lw,zorder=1))
    def panel(x,y,letter,title):
        t(x,y,letter,11.2,navy,bold=True);t(x+6.4,y,title,10.1,navy,bold=True)
    def cad():
        z=np.load(D/'elliptical.npz'); p=z['pts'][:,[2,0,1]]; f=z['faces']
        def unit(v):return v/np.linalg.norm(v)
        eye=unit(np.array([-.43,-.79,.43]));right=unit(np.cross(eye,[0,0,1.]));up=unit(np.cross(right,eye));q=p@np.array([right,up,eye]).T
        th=.10;q[:,:2]=q[:,:2]@np.array([[np.cos(th),np.sin(th)],[-np.sin(th),np.cos(th)]])
        tris=q[f];n=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);n/=np.maximum(1e-13,np.linalg.norm(n,axis=1))[:,None]
        n[n[:,2]<0]*=-1
        light=unit(np.array([-.35,.72,.60]));v=np.clip(n@light,0,1)*.8+.2
        lo=np.array([.15,.28,.34]);hi=np.array([.80,.89,.9])
        col=lo+(hi-lo)*v[:,None]
        sort=np.argsort(tris[:,:,2].mean(1));b=q[:,:2].min(0);B=q[:,:2].max(0);sf=min(39/(B[0]-b[0]),19/(B[1]-b[1]))
        xy=(tris[sort,:,:2]-(B+b)/2)*[sf,-sf]+[24.3,25.5]
        ax.add_collection(PolyCollection(xy,facecolors=col[sort],edgecolors=col[sort]*.84,lw=.105,zorder=2))
    panel(2,4.7,'a',L('From cavity geometry to a finite-element trial basis','Kavite geometrisinden sonlu eleman deneme bazına'))
    for x,ww,label,col in [(2,45,L('Cavity mesh','Kavite ağı'),navy),(54,64,L('Learned field generator','Öğrenilen alan üreteci'),teal),(127,51,L('Finite-element map','Sonlu eleman dönüşümü'),navy)]:
        ln([(x,9.1),(x+ww,9.1)],col,.95);t(x+ww/2,13,label,8.4,col,'center',True)
    cad()
    t(24.5,40.1,L('Quadrature tokens','Kuadratür girdileri'),7.8,txt,'center')
    t(24.5,46.3,r'$x_q,\; g_q,\; w_q$',9.2,navy,'center')
    # Learned operations; the fan of outlines denotes repetition, not a width parameter.
    rect(55.8,18.0,60.4,5.7,'#F1F7F6');t(86,20.9,L('Fourier features + MLP encoder','Fourier öznitelikleri + MLP kodlayıcı'),7.1,teal,'center')
    arrow(86,23.9,86,26.0,teal,ms=6)
    rect(56,26.4,60,9.0,pale,teal,.75)
    t(86,29.1,L('Weighted linear attention','Ağırlıklı doğrusal dikkat'),7.9,teal,'center',True)
    t(86,33.0,L('4 blocks · 4 heads · width 128','4 blok · 4 baş · 128 kanal'),7.2,teal,'center')
    arrow(86,35.8,86,38.1,teal,ms=6)
    t(86,40.9,L('Field head + Fourier features','Alan çıkışı + Fourier öznitelikleri'),7.8,txt,'center')
    t(86,46.3,r'$\psi_j(x_q)\in\mathbb{R}^3,\quad j=1,\ldots,24$',9,teal,'center')
    arrow(45.2,28.8,53.3,28.8);arrow(118.1,28.8,125.3,28.8)
    # An oriented element and an array of coefficients. The matrix pattern is purely schematic.
    v=np.array([[130,33],[146,33],[141,18],[135,27]])
    for i,j in ((0,1),(1,2),(2,0),(0,3),(1,3),(2,3)):
        ln([v[i],v[j]],'#748D96',.72,'--' if (i,j)==(2,3) else '-')
    for p in [(135.4,30.6),(140.4,30.4),(140.1,25.6),(137.5,28.1)]:
        ax.add_patch(Circle(p,.52,color=teal,zorder=4))
    arrow(147.9,26.5,154.6,26.5,gray,ms=7)
    for i in range(5):
        for j in range(6):
            fc=['#cbd9db','#68949b','#345b6b','#8ab3b7'][(i*7+j*3+i*j)%4]
            ax.add_patch(Rectangle((157+j*2.3,20.7+i*2.3),2.12,2.12,facecolor=fc,edgecolor='none'))
    t(152.3,40.1,L('Local fit → Nédélec ($p=2$)','Yerel uyum → Nédélec ($p=2$)'),7.7,txt,'center')
    t(152.3,46.4,L('PEC mask → trial basis  $V$','PEC maskesi → deneme bazı  $V$'),7.5,navy,'center')
    # V is shared by physically constrained inference and the projection-free training objective.
    ln([(152.3,49.1),(152.3,53),(54,53),(54,56)],navy,.88);arrow(54,55.6,54,58.1)
    arrow(152.3,53,152.3,58.1,warm);ax.add_patch(Circle((152.3,53),.56,color=navy,zorder=7))
    rect(2,60,103,76.6,'#F2F6F7',r=1.3);rect(109,60,69,76.6,sand,r=1.3)
    panel(5.3,65.4,'b',L('Physical mode extraction','Fiziksel modların çıkarımı'))
    panel(112,65.4,'c',L('Projection-free training','İzdüşümsüz eğitim'))
    # Three consecutive operations in b, anchored by drawings with a vertical flow.
    for x1,x2,y in [(5.6,101.4,87.6),(5.6,101.4,108.7)]:ln([(x1,y),(x2,y)],'#CDDADC',.48)
    ln([(8,82.3),(28,82.3)],gray,.55)
    arrow(9,82.1,23.5,73.3,warm,.9);arrow(9,82.1,23.5,82.1,navy,1)
    ln([(23.5,73.4),(23.5,81.7)],gray,.58,'--')
    t(31.8,72.8,L('Remove the gradient component','Gradyan bileşenini çıkar'),8.2,navy,bold=True)
    t(31.8,78.1,r'$(G^{\mathsf{T}}MG)Z=G^{\mathsf{T}}MV$',9.2)
    t(31.8,83.1,r'$W=V-GZ$',9.2)
    # The reduced generalized eigensystem is symmetric.
    for i in range(4):
        for j in range(4):
            fc=['#467782','#91b1b6','#b8cdd1','#d7e3e6'][abs(i-j)]
            ax.add_patch(Rectangle((9.5+j*2.7,92+i*2.7),2.5,2.5,facecolor=fc,edgecolor='none'))
    ln([(8.9,91.4),(8.0,91.4),(8.0,103.2),(8.9,103.2)],gray,.65)
    ln([(20.8,91.4),(21.7,91.4),(21.7,103.2),(20.8,103.2)],gray,.65)
    t(31.8,93.0,L('Rayleigh–Ritz eigenproblem','Rayleigh–Ritz özproblemi'),8.2,navy,bold=True)
    t(31.8,98.7,r'$(W^{\mathsf{T}}KW)a_i=\theta_i(W^{\mathsf{T}}MW)a_i$',9.1)
    t(31.8,104.1,L('Retain independent directions.','Bağımsız yönleri tut.'),7.5,gray)
    # Schematic glyph of a discrete spectrum; no experimental values are implied.
    ln([(8,128),(27.1,128)],gray,.6)
    for x,h in [(10,3.8),(13,7.3),(16,7.6),(19,10),(22,12.1),(25,15)]:
        ln([(x,128),(x,128-h)],teal,1.15)
    t(31.8,114.1,L('Six lowest physical modes','En düşük altı fiziksel mod'),8.2,navy,bold=True)
    t(31.8,120.6,r'$u_i=Wa_i,\quad u_i^{\mathsf{T}} M u_i=1$',9.1)
    t(31.8,127.1,r'$f_i=c_0\sqrt{\theta_i}/(2\pi s)$',9.1)
    t(31.8,132.2,L('Electric fields and resonant frequencies','Elektrik alanları ve rezonans frekansları'),7,gray)
    # Geometric least-approximation sketch, visually distinct from the physical kernel projection.
    ax.add_patch(Polygon([(117,88),(132,91),(147,83.5),(132,80.6)],fc='#E8DAC3',ec='#AF9675',lw=.7))
    origin=(126,86.2); best=(138,85); target=(138,73.6)
    arrow(*origin,*best,navy,.85);arrow(*origin,*target,warm,1.1);ln([best,target],warm,.7,'--')
    t(139.1,73.4,r'$t_i$',9,warm);t(144.1,90.1,r'$\mathrm{span}(V)$',8,gray)
    t(112.7,96.9,L('Fit reference FE modes','Referans modlara en iyi yaklaşım'),8.2,warm,bold=True)
    t(112.7,103.4,r'$\min_{a}\,\|t_i-Va\|_H^2,\quad H\in\{M,K\}$',9)
    t(112.7,109.0,L('Mass and curl-energy residuals','Kütle ve rotasyonel enerji hataları'),7.6)
    t(112.7,115.3,L('Basis conditioning penalty','Baz koşullandırma cezası'),7.6)
    ln([(112.7,120.2),(174.8,120.2)],'#D8C7AD',.6)
    t(112.7,125.4,L('Test and inference use','Test ve tahminde fiziksel'),7.7,warm,bold=True)
    t(112.7,130.0,L('the physical branch (b).','kol (b) kullanılır.'),7.7,warm,bold=True)
    for ext in ['pdf','svg','png']:
        fig.savefig(D/('rf-model-'+lang+'.'+ext),dpi=325,facecolor='white')
    plt.close(fig)
for lang in ['tr','en']:render(lang)
