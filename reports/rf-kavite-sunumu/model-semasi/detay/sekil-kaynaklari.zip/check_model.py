"""Trace the configured field3d model on a small PEC cylinder; no training."""
import json
from pathlib import Path
import torch
import yaml
from netgen.occ import Axes, Cylinder, OCCGeometry, Z
from ngsolve import Mesh
from src.data.field_dataset import field_collate, field_item
from src.data_gen.highorder import field_operators
from src.models.eigenspace_operator_field import EigenspaceOperatorField

conf = yaml.safe_load(Path('configs/field_3d_noproj.yaml').read_text())['model']
args = {k: conf[k] for k in ('embed_dim','n_heads','n_basis','num_field_modes','rff_dim','rff_length_scale','dropout')}
torch.manual_seed(0)
m = EigenspaceOperatorField(val_dim=9, **args, **conf['eigenspace']).eval()
m.freq_stats = {'mean': 0., 'std': 1.}  # Dummy statistics for a shape check only.
geo = Cylinder(Axes((0, 0, 0), Z), r=.1, h=.1)
geo.faces.name = 'wall'
mesh = Mesh(OCCGeometry(geo).GenerateMesh(maxh=.075))
mesh.Curve(2)
ops = field_operators(mesh)
batch = field_collate([field_item(ops)])
trace = {k:list(batch[k].shape) for k in ('X','Input_funcs','Area','QP','C','G','M','K')}
def record(name):
    def hook(module, args, output):
        trace[name] = [list(args[0].shape), list(output.shape)]
    return hook
for key, layer in [('encoder',m.encoder),('fourth_norm',m.blocks[3].norm1),('FFN_hidden',m.blocks[0].ffn[0]),('head',m.edge_head)]:
    layer.register_forward_hook(record(key))
with torch.inference_mode():
    result = m(batch)
trace.update({k:list(result[k].shape) for k in ('basis','field','eigenvalues','freq')})
trace['trainable'] = sum(p.numel() for p in m.parameters() if p.requires_grad)
print(json.dumps(trace,indent=1))
