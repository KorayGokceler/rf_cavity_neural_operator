"""Bilingual vector figures. Run with numpy and matplotlib. See check_model.py for the tensor trace."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib.collections import PolyCollection

D=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'stix','pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'rf-detail'})
ink='#173748'; mute='#436371'; aqua='#006B68'; ochre='#8B481D'; edge='#B9CCCF'
water='#E8F4F1'; mist='#EFF4F6'; sand='#FBF2E6'; white='#FFFFFF'
width,height=240,173
trace=json.loads((D/'trace.json').read_text())
class Sheet:
    def __init__(self,lang,tag,title):
        self.lang=lang
        self.fig=plt.figure(figsize=(width/25.4,height/25.4),facecolor='white')
        self.ax=self.fig.add_axes([0,0,1,1])
        self.ax.set(xlim=(0,width),ylim=(height,0),aspect='equal');self.ax.axis('off')
        self.label(6,7.5,tag,12,aqua,weight=True)
        self.label(17,7.4,title,15,ink,weight=True)
        self.line([(6,14),(234,14)],edge,.85)
    def L(self,tr,en):return tr if self.lang=='tr' else en
    def label(self,x,y,s,size=9.5,color=ink,align='left',weight=False):
        return self.ax.text(x,y,s,fontsize=size,color=color,ha=align,va='center',weight='bold' if weight else 'regular',zorder=6)
    def line(self,pts,c=edge,lw=.85,ls='-'):
        a=np.array(pts);self.ax.plot(*a.T,color=c,lw=lw,ls=ls,zorder=3,solid_capstyle='round',solid_joinstyle='round')
    def arr(self,pts,c=ink):
        if len(pts)>2:self.line(pts[:-1],c,.9)
        self.ax.add_patch(FancyArrowPatch(pts[-2],pts[-1],arrowstyle='-|>',mutation_scale=8.5,shrinkA=0,shrinkB=0,color=c,lw=.9,zorder=4))
    def bg(self,x,y,w,h,fc=mist,ec='none'):
        self.ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.4',fc=fc,ec=ec,lw=.65,zorder=0))
    def title(self,x,y,s,c=aqua):self.label(x,y,s,10,c,weight=True)
    def foot(self,s):
        self.line([(6,162),(234,162)])
        self.label(6,166.8,s,8.5,mute)
    def cell(self,x,y,w,h,title,rows,fc=water,col=aqua):
        self.bg(x,y,w,h,fc)
        self.label(x+w/2,y+5,title,10.1,col,'center',True)
        for j,row in enumerate(rows):
            self.label(x+w/2,y+12+j*5.5,row,9.2,ink,'center')
    def cavity(self,x,y,w,h):
        z=np.load(D/'elliptical.npz');p=z['pts'][:,[2,0,1]];f=z['faces']
        unit=lambda a:a/np.linalg.norm(a)
        eye=unit(np.array([-.42,-.79,.43]));right=unit(np.cross(eye,[0,0,1.]));up=np.cross(right,eye)
        q=p@np.array([right,up,eye]).T;tri=q[f]
        n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);n/=np.maximum(1e-12,np.linalg.norm(n,axis=1))[:,None];n[n[:,2]<0]*=-1
        v=np.clip(n@unit(np.array([-.35,.72,.6])),0,1)*.8+.2
        colors=np.array([.12,.26,.32])+v[:,None]*np.array([.69,.63,.59])
        idx=np.argsort(tri[:,:,2].mean(1));lo=q[:,:2].min(0);hi=q[:,:2].max(0);scale=min(w/(hi-lo)[0],h/(hi-lo)[1])
        xy=(tri[idx,:,:2]-(lo+hi)/2)*[scale,-scale]+[x,y]
        self.ax.add_collection(PolyCollection(xy,facecolors=colors[idx],edgecolors=colors[idx]*.91,lw=.085,zorder=2))

def overview(lang):
    tr=lang=='tr';s=Sheet(lang,'A','Geometriden rezonans modlarına' if tr else 'From cavity geometry to resonant modes');L=s.L;t=s.label
    s.title(6,21,L('Bir kavite','One cavity'),ink);s.cavity(29,39,45,22)
    t(6,55,L('Her dört yüzlüde 14 nokta','14 points per tetrahedron'),9)
    t(6,61,r'$N=14\,N_{\rm tet}$',10)
    s.arr([(54,40),(60,40)])
    s.bg(62,18,109,48,mist)
    s.title(65,24,L('Bir kuadratür noktasının girdi vektörü','Input vector at one quadrature point'),ink)
    t(65,32,r'$g_q=[\,\xi_x,\xi_y,\xi_z,\ d_q,\ b_x,b_y,b_z,\ \rho_q,\ \tau_q\,]\;\in\mathbb{R}^{9}$',12)
    t(65,40,L('3 konum  ·  1 duvar mesafesi  ·  3 en yakın duvar yönü','3 coordinates  ·  1 wall distance  ·  3 directions to wall'),9.1)
    t(65,47,L('1 bağıl nokta hacmi  ·  1 normalize torsiyon değeri','1 relative point volume  ·  1 normalized torsion value'),9.1)
    t(65,57,r'$\rho_q=\omega_q/\max_r\omega_r\qquad w_q=\omega_q/\sum_r\omega_r$',10)
    s.bg(174,18,60,48,mist)
    s.title(177,24,L('Konum kodu','Position code'),ink)
    t(177,33,r'$\xi_q=(x_q-c)/s$',11)
    t(177,41,r'$\gamma_q=\sqrt{2/64}\,[\cos(\xi_q B),$',10.1)
    t(183,47,r'$\sin(\xi_q B)]\in\mathbb{R}^{64}$',10.1)
    t(177,57,L('32 sabit Fourier frekansı','32 fixed Fourier frequencies'),8.8,mute)
    s.title(58,74,L('Öğrenilen dönüşüm','Learned transformation'))
    xs=[6,58,116,180];ws=[45,51,57,54]
    labels=[L('Birleştir','Concatenate'),L('Nokta kodlayıcı','Point encoder'),L('Kavite içi dikkat','Cavity-wide attention'),L('Vektör alanı çıkışı','Vector field head')]
    rows=[[r'$[\gamma_q,g_q]\in\mathbb{R}^{73}$',L('64 + 9 kanal','64 + 9 channels')],[r'$73\;\to\;128\;\to\;128$',L('LayerNorm ve GELU','LayerNorm and GELU')],[L('4 blok × 4 baş × 32 kanal','4 blocks × 4 heads × 32'),L('hacim ağırlıkları ile','using volume weights')],[r'$[h_q,\gamma_q]:\ 192\to128\to72$',L('24 adet 3B vektör','24 vectors in 3D')]]
    for i in range(4):
        s.cell(xs[i],80,ws[i],25,labels[i],rows[i])
        if i<3:s.arr([(xs[i]+ws[i]+.5,92),(xs[i+1]-.6,92)],aqua)
    s.arr([(203,66),(203,69),(28,69),(28,79.6)],mute)
    s.line([(111,66),(111,69)],mute,.9)
    s.arr([(213,66),(213,79.6)],mute)
    s.arr([(147,66),(147,79.6)],mute)
    t(150,72.6,r'$w_q$',9,mute)
    s.title(6,115,L('Fiziksel okuma','Physical readout'),ink)
    s.cell(6,121,48,33,L('Noktasal alanlar','Pointwise fields'),[r'$\Psi\in\mathbb{R}^{N\times24\times3}$',r'$\psi_j=(\psi_{jx},\psi_{jy},\psi_{jz})$',L('her noktada 24 üçlü','24 triples per point')],mist,ink)
    s.cell(62,121,50,33,L('Sonlu eleman bazı','Finite-element basis'),[r'$V\in\mathbb{R}^{D\times24}$',L('yerel uyum + Nédélec','local fit + Nédélec'),L('iletken duvar maskesi','conducting wall mask')],mist,ink)
    s.cell(120,121,51,33,L('Fiziksel alt uzay','Physical subspace'),[r'$W=V-GZ$',L('gradyanları ayıkla','remove gradients'),L('Rayleigh–Ritz çözümü','Rayleigh–Ritz solve')],mist,ink)
    s.cell(179,121,55,33,L('Mod alanları ve frekans','Mode fields and frequencies'),[r'$U=[u_1,\ldots,u_6]\in\mathbb{R}^{D\times6}$',r'$f=(f_1,\ldots,f_6)\in\mathbb{R}^6$',L('her sütun bir özmod','one eigenmode per column')],mist,ink)
    s.arr([(208,105),(208,117),(30,117),(30,120.7)],ink)
    for x in (54,112,171):s.arr([(x+.5,138),(x+7.4,138)],ink)
    s.foot(L('Tek kavite gösterilmiştir. D, H(curl) serbestlik derecesi sayısıdır. B paneli öğrenilen katmanları, C paneli fizik ve eğitim yollarını açar.','One cavity is shown. D counts H(curl) degrees of freedom. Panel B expands the learned layers; panel C expands physics and training.'))
    return s

def layers(lang):
    tr=lang=='tr';s=Sheet(lang,'B','Sinir operatörünün katmanları' if tr else 'Inside the neural operator');L=s.L;t=s.label
    s.title(6,21,L('Noktasal kodlayıcı','Pointwise encoder'))
    s.bg(6,26,228,19,water)
    t(10,32,r'$[\gamma_q,g_q]_{73}\;\longrightarrow\;\mathrm{Linear}_{73\to128}\;\longrightarrow\;\mathrm{LayerNorm}_{128}\;\longrightarrow\;\mathrm{GELU}\;\longrightarrow\;\mathrm{Linear}_{128\to128}\;\longrightarrow\;h_q^{(0)}$',14)
    t(10,40,L('Her konumda aynı ağırlıklar kullanılır. Başlangıç tensörü kavite başına N × 128 değer taşır.','All positions share the encoder weights. Each cavity enters the attention stack as an N × 128 tensor.'),9)
    s.title(6,52,L('Bir dikkat bloğu','One attention block'))
    t(54,52,L('Dört kez uygulanır. Her bloğun ağırlıkları ayrıdır.','Repeated four times with separate weights in each block.'),9,mute)
    s.cell(6,63,41,29,L('Ön normalizasyon','Pre-normalization'),[r'$h_q\in\mathbb{R}^{128}$',r'$y_q=\mathrm{LN}_1(h_q)$'],water)
    s.cell(54,63,47,29,L('Üç doğrusal dönüşüm','Three linear maps'),[r'$Q_q,\ K_q,\ v_q$',L('her biri 4 × 32','each split into 4 × 32')],water)
    s.cell(108,63,71,29,L('Her baş kaviteyi toplar','Each head integrates the cavity'),[r'$\phi(a)=\mathrm{ELU}(a)+1$',r'$S=\sum_r w_r\phi(K_r)v_r^{\mathsf{T}},\quad z=\sum_r w_r\phi(K_r)$'],water)
    s.cell(186,63,48,29,L('Başları birleştir','Concatenate heads'),[r'$4\times32\to128$',r'$p_q=W_o[\,o_q^1;\ldots;o_q^4\,]+b_o$'],water)
    for x in (47,101,179):s.arr([(x+.5,78),(x+6.5,78)],aqua)
    s.line([(7,59),(233,59)],edge,.65)
    s.bg(6,96,107,26,mist);s.title(9,102,L('Bir başın okuması','Readout from one head'),ink)
    t(9,112,r'$o_q=S^{\mathsf{T}}\phi(Q_q)\,/\,[\,\phi(Q_q)^{\mathsf{T}}z+10^{-6}\,]$',12)
    s.bg(116,96,118,26,water);s.title(119,102,L('İki artık bağlantı','Two residual connections'))
    t(119,111,r'$u_q=h_q+p_q\qquad h_q^{\prime}=u_q+\mathrm{FFN}(\mathrm{LN}_2(u_q))$',11.6)
    t(119,118,L('FFN  128 → 512 → GELU → 128. Dolgu noktaları sıfırlanır.','FFN  128 → 512 → GELU → 128. Padded positions are zeroed.'),8.7)
    s.arr([(216,92),(216,95.5)],aqua)
    s.title(6,130,L('Dördüncü bloktan sonra','After the fourth block'))
    s.bg(6,135,228,22,mist)
    t(10,141.5,r'$h_q=\mathrm{LN}(h_q^{(4)})\quad\longrightarrow\quad [h_q,\gamma_q]_{192}\quad\longrightarrow\quad\mathrm{Linear}_{192\to128}\quad\longrightarrow\quad\mathrm{GELU}\quad\longrightarrow\quad\mathrm{Linear}_{128\to72}$',12.1)
    t(10,151,L('72 sayı sırayla 24 üçlüye açılır. Aynı sabit Fourier kodu girişte ve çıkış katmanında kullanılır.','The 72 channels are reshaped into 24 triples. The same fixed Fourier code enters both the encoder and the field head.'),9.1)
    s.foot(L('r, kavitedeki geçerli noktaları tarar. Her baş için S boyutu 32 × 32, z boyutu 32’dir. Tüm modelde 853 576 öğrenilebilir parametre vardır.','r runs over valid cavity points. Per head, S has shape 32 × 32 and z has length 32. The full model has 853,576 trainable parameters.'))
    return s

def physics(lang):
    tr=lang=='tr';s=Sheet(lang,'C','Aday alanlardan fiziksel çıktılara' if tr else 'From trial fields to physical outputs');L=s.L;t=s.label
    s.title(6,21,L('Noktasal değerler sonlu eleman katsayılarına nasıl dönüşür?','How do point samples become finite-element coefficients?'),ink)
    s.cell(6,26,56,25,L('Bir dört yüzlü','One tetrahedron'),[r'$\Psi_e\in\mathbb{R}^{14\times24\times3}$',L('14 nokta · 24 alan · 3 bileşen','14 points · 24 fields · 3 components')],mist,ink)
    s.cell(69,26,80,25,L('Yerel ikinci derece polinom uyumu','Local quadratic polynomial fit'),[r'$P_e=(\Phi_e^\mathsf{T}D_e\Phi_e)^{-1}\Phi_e^\mathsf{T}D_e\in\mathbb{R}^{10\times14}$',L('Bileşen başına 10 katsayı, hacim ağırlıkları Dₑ.','10 coefficients per component with volume weights in Dₑ.')],mist,ink)
    s.cell(156,26,78,25,L('Nédélec uzayına aktarım','Map into the Nédélec space'),[r'$V=\mathrm{mask}_{\rm PEC}\,(C\,\mathrm{vec}(P\Psi))\in\mathbb{R}^{D\times24}$',L('Duvardaki teğetsel serbestlikler sıfırlanır.','Tangential wall degrees of freedom are zeroed.')],mist,ink)
    for x in (62,149):s.arr([(x+.5,38),(x+6.5,38)],ink)
    s.arr([(195,51.5),(195,55),(66,55),(66,59)],ink);s.arr([(195,55),(195,59)],ochre)
    s.bg(6,60,114,70,mist);s.bg(124,60,110,70,sand)
    s.title(10,66,L('Tahmin ve test','Inference and test'),ink)
    t(10,75,L('1   Gradyan alanlarını kütle iç çarpımında çıkar.','1   Remove gradient fields in the mass inner product.'),9.1)
    t(14,82,r'$(G^\mathsf{T}MG)Z=G^\mathsf{T}MV,\quad W=V-GZ$',11.3)
    t(10,92,L('2   Küçük özproblemi kalan bağımsız yönlerde çöz.','2   Solve the reduced eigenproblem on retained directions.'),9.1)
    t(14,99,r'$(W^\mathsf{T}KW)a_i=\theta_i(W^\mathsf{T}MW)a_i$',11.6)
    t(10,109,L('3   Altı en düşük geçerli mod için alan ve frekansı kur.','3   Recover fields and frequencies for the six lowest valid modes.'),9)
    t(14,116,r'$u_i=Wa_i/\|Wa_i\|_M,\qquad f_i=c_0\sqrt{\theta_i}/(2\pi s)$',11.3)
    t(10,124.5,L('freq, GHz frekansının eğitim istatistikleriyle z-skorudur.','freq stores GHz as a z-score using the training statistics.'),8.8,mute)
    s.title(128,66,L('İzdüşümsüz eğitim ve doğrulama','Projection-free training and validation'),ochre)
    t(128,75,L('Her referans mod tᵢ için bazın en iyi yaklaşımını bul.','For each reference mode, find its best fit in the trial basis.'),9.1)
    t(131,83,r'$r_{H,i}\simeq\min_a\,\|t_i-Va\|_H^2/\|t_i\|_H^2,\quad H\in\{M,K\}$',10.7)
    t(128,92,L('Kütle ve rotasyonel enerji hatalarını birleştir.','Combine mass and curl-energy errors.'),9.1)
    t(131,100,r'$\mathcal{L}_{\rm span}=\mathrm{mean}_i\,\sqrt{(r_{M,i}+r_{K,i})/2+10^{-8}}$',11)
    t(131,112,r'$\mathcal{L}=\mathcal{L}_{\rm span}+0.01\,\mathcal{L}_{\rm ortho}$',11.3)
    t(128,120,L('Son terim enerji Gram matrisindeki sütun korelasyonlarını','The last term penalizes column correlations in the energy'),8.6)
    t(128,125,L('cezalandırır. Bu kolda gradyan ve Ritz çözümleri atlanır.','Gram matrix. This branch skips the gradient and Ritz solves.'),8.6)
    s.title(6,138,L('Çalıştırılmış tensör örneği','Tensor trace from a forward pass'),ink)
    t(85,138,L('Tek silindirik kavite · 111 eleman · rastgele başlangıç ağırlıkları','One cylindrical cavity · 111 elements · randomly initialized weights'),8.9,mute)
    s.bg(6,143,228,15,mist)
    t(10,148.1,L('Girdi','Input'),9,ink,weight=True);t(23,148.1,'1 554 × 9',9.6)
    t(58,148.1,L('Kodlayıcı','Encoder'),9,ink,weight=True);t(81,148.1,'1 554 × 128',9.6)
    t(128,148.1,L('Deneme bazı','Trial basis'),9,ink,weight=True);t(156,148.1,'1 470 × 24',9.6)
    t(10,154.1,'field',9,ink,weight=True);t(23,154.1,'1 470 × 6',9.6)
    t(58,154.1,'eigenvalues',9,ink,weight=True);t(85,154.1,'6',9.6)
    t(128,154.1,'freq',9,ink,weight=True);t(156,154.1,'6',9.6)
    s.foot(L('M kütle, K rotasyonel enerji, G ayrık gradyan matrisidir. s geometrinin uzunluk ölçeğidir. Altı mod için izdüşmüş bazın rütbesi en az altı olmalıdır.','M is mass, K is curl–curl stiffness, G is the discrete gradient and s is the length scale. Six modes require a projected basis of rank at least six.'))
    return s

if __name__=='__main__':
    for lang in ('tr','en'):
        with PdfPages(D/f'rf-model-detay-{lang}.pdf') as pdf:
            for index,fn in enumerate((overview,layers,physics)):
                sheet=fn(lang);pdf.savefig(sheet.fig)
                name=['rf-model','rf-katmanlar','rf-fizik'][index]
                for ext in ('pdf','png','svg'):
                    sheet.fig.savefig(D/f'{name}-{lang}.{ext}',dpi=300,facecolor='white')
                plt.close(sheet.fig)
