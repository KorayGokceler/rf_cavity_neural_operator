"""Build the camera-ready figures. Run from the directory containing the data exports."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap
from scipy.special import j0, jn_zeros
from scipy.constants import c
out=Path('figures');out.mkdir(exist_ok=True)
ink='#112d3a'; blue='#096979'; copper='#b95536'; gold='#dd9251'; gray='#47636c'; grid='#dce7e6'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.labelcolor':ink,'xtick.color':gray,'ytick.color':gray,'text.color':ink,'axes.spines.right':False,'axes.spines.top':False,'axes.edgecolor':grid,'axes.titleweight':'bold','axes.titlelocation':'left','savefig.facecolor':'white','pdf.fonttype':42})
def save(fig,name,pdf=True):
    fig.savefig(out/(name+'.png'),dpi=190,bbox_inches='tight',pad_inches=.085)
    if pdf:fig.savefig(out/(name+'.pdf'),bbox_inches='tight',pad_inches=.085)
    plt.close(fig)
def norm(a):return a/np.linalg.norm(a)
def cad(ax,name,mesh=False,hero=False):
    d=np.load('surface_'+name+'.npz');p=d['pts'][:,[2,0,1]];f=d['faces']
    az=-.92; eye=norm(np.array([-.43,-.79,.43]));right=norm(np.cross(eye,[0,0,1.]));up=norm(np.cross(right,eye))
    cam=np.array([right,up,eye]).T; pp=p@cam
    # Slight rotation around the view axis lifts the long axis diagonally.
    theta=.13;pp[:,:2]=pp[:,:2]@np.array([[np.cos(theta),np.sin(theta)],[-np.sin(theta),np.cos(theta)]])
    coords=pp[f];n=np.cross(coords[:,1]-coords[:,0],coords[:,2]-coords[:,0]);n/=np.maximum(1e-14,np.linalg.norm(n,axis=1))[:,None]
    n[n[:,2]<0]*=-1
    light=norm(np.array([-.30,.72,.62])); diffuse=(n@light).clip(0,1)
    half=norm(light+np.array([0,0,1]));spec=(n@half).clip(0,1)**17
    material=np.array([.78,.45,.26]) if hero else np.array([.28,.60,.64])
    rgb=np.clip(material[None,:]*(.38+.71*diffuse[:,None])+.35*spec[:,None]+.065,0,1)
    order=np.argsort(coords[:,:,2].mean(1))
    ax.add_collection(PolyCollection(coords[order,:,:2],facecolors=rgb[order],edgecolors=('#173b49' if mesh else rgb[order]),linewidths=(.23 if mesh else .33),antialiased=True,rasterized=True))
    ax.autoscale();ax.set_aspect('equal');ax.margins(.018);ax.axis('off')
fig,ax=plt.subplots(figsize=(8,4));cad(ax,'elliptical',hero=True);fig.patch.set_alpha(0)
fig.savefig(out/'01_kavite.png',transparent=True,bbox_inches='tight',pad_inches=.03,dpi=240);plt.close(fig)
fig,axs=plt.subplots(2,2,figsize=(7.4,4.8))
for ax,name,title in zip(axs.flat,['elliptical','reentrant','ridged_box','spoke'],['Eliptik, dört hücre','Yeniden girintili','Sırtlı kutu','Spoke']):
    cad(ax,name);ax.set_title(title,fontsize=12,loc='center',pad=0)
fig.subplots_adjust(hspace=.20,wspace=.08);save(fig,'02_aileler',False)
fig,ax=plt.subplots(figsize=(6.5,3.3));cad(ax,'elliptical',mesh=True);save(fig,'03_yuzey_agi',False)
# Analytic design sweep
r=np.linspace(6,13,200); freq=c*jn_zeros(0,1)[0]/(2*np.pi*r*.01)/1e9
fig,ax=plt.subplots(figsize=(6.4,3.1));ax.plot(r,freq,color=blue,lw=3.5);ax.fill_between(r,0.75,freq,color='#e1efef');ax.set_ylim(.75,2.08);ax.set_xlim(6,13);ax.grid(axis='y',color=grid);ax.set(xlabel='Kavite yarıçapı (cm)',ylabel='Rezonans (GHz)')
for a in [8,10,12]:
    b=c*jn_zeros(0,1)[0]/(2*np.pi*a*.01)/1e9
    ax.scatter(a,b,color=copper,s=47,zorder=5);ax.annotate(f'{b:.2f}'.replace('.',','),(a,b),xytext=(8,9),textcoords='offset points',weight='bold')
save(fig,'04_yaricap')
# Actual FE solution, transverse cuts of E and H magnitudes.
d=np.load('fe_section.npz');v=d['v']*100
cmap=LinearSegmentedColormap.from_list('field',['#122d49','#19667e','#39a499','#c6d782','#ffcc60','#c85332'])
fig,axs=plt.subplots(1,2,figsize=(7.6,3.8),layout='constrained')
for ax,arr,title in zip(axs,[np.abs(d['E']),d['B']],[r'Elektrik alanı  $|E_z|$',r'Manyetik akı yoğunluğu  $|B|$']):
    im=ax.imshow(arr,origin='lower',extent=[v.min(),v.max(),v.min(),v.max()],cmap=cmap,vmin=0,vmax=1)
    ax.set_title(title,fontsize=12,loc='center');ax.set_xlabel('x (cm)');ax.set_ylabel('y (cm)');ax.set_xticks([-10,0,10]);ax.set_yticks([-10,0,10])
cb=fig.colorbar(im,ax=axs,location='bottom',shrink=.67,aspect=40,pad=.02,ticks=[0,.5,1]);cb.set_label('Her alan kendi referans genliğine ölçeklendi',fontsize=10)
save(fig,'05_fe_alanlari')
# Training diagram. Columns correspond to operations that really run.
def box(ax,x,y,w,h,title,detail,fc):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.015,rounding_size=.09',edgecolor='none',facecolor=fc))
    ax.text(x+w/2,y+h*.63,title,ha='center',va='center',fontsize=15,weight='bold');ax.text(x+w/2,y+h*.28,detail,ha='center',va='center',fontsize=11)
def arr(ax,x,y,x2,y2):
    ax.add_patch(FancyArrowPatch((x,y),(x2,y2),arrowstyle='-|>',mutation_scale=15,linewidth=1.6,color=gray))
fig,ax=plt.subplots(figsize=(11.5,2.8));ax.set(xlim=(0,12),ylim=(0,3.35));ax.axis('off')
for x,t,b,fc in [(0.1,'Geometri','Eğri tetra ağı','#e7eded'),(3.2,'Dikkat katmanları','Kuadratürde aday alanlar','#dfefec'),(6.3,'Nédélec bazı','Duvar koşulu ve izdüşüm','#ecf0dd'),(9.4,'Ritz çözümü','Frekans ve alan','#f5e3d5')]:
    box(ax,x,1.24,2.48,1.06,t,b,fc)
    if x<9:arr(ax,x+2.52,1.77,x+3.03,1.77)
ax.plot([.1,2.58],[.88,.88],color=gray);ax.plot([3.2,5.68],[.88,.88],color=blue);ax.plot([6.3,11.88],[.88,.88],color=copper)
for x,t in [(1.34,'Girdi'),(4.44,'Öğrenilen adım'),(9.05,'Fiziksel operatörler')]:ax.text(x,.52,t,ha='center',color=gray,fontsize=12)
save(fig,'06_mimari')
# Spatial quadrature schematic intentionally 2D; same total mass split between samples.
fig,axs=plt.subplots(1,2,figsize=(7.1,3.4))
for ax,edges,label in zip(axs,[np.linspace(0,1,6),np.r_[np.linspace(0,.4,8),.6,.8,1]],['Eşit aralık','Solda daha sık']):
    yy=np.linspace(0,1,6)
    for x in edges:ax.plot([x,x],[0,1],color=grid,lw=1)
    for y in yy:ax.plot([0,1],[y,y],color=grid,lw=1)
    for x0,x1 in zip(edges[:-1],edges[1:]):
        for y0,y1 in zip(yy[:-1],yy[1:]):
            ax.scatter((x0+x1)/2,(y0+y1)/2,s=1900*(x1-x0)*(y1-y0),color=blue)
    ax.set(xlim=(-.03,1.03),ylim=(-.03,1.03),aspect=1);ax.axis('off');ax.set_title(label,loc='center',fontsize=13)
save(fig,'07_kuadratur')
# A true scalar component of two degenerate PEC box TM modes, cross sections.
v=np.linspace(0,1,130);X,Y=np.meshgrid(v,v)
a=np.sin(np.pi*X)*np.sin(2*np.pi*Y);b=np.sin(2*np.pi*X)*np.sin(np.pi*Y)
fig,axs=plt.subplots(2,2,figsize=(5.2,4.6)); cm=LinearSegmentedColormap.from_list('signed',[blue,'white',copper])
for ax,field,lab in zip(axs.flat,[a,b,(a+b)/np.sqrt(2),(b-a)/np.sqrt(2)],[r'$u_1$',r'$u_2$',r'$(u_1+u_2)/sqrt{2}$',r'$(u_2-u_1)/sqrt{2}$']):
    ax.imshow(field,origin='lower',cmap=cm,vmin=-1.15,vmax=1.15);ax.axis('off');ax.set_title(lab,loc='center',fontsize=13,pad=3)
fig.subplots_adjust(hspace=.23,wspace=.02);save(fig,'08_dejenere_modlar')
# Projection diagram for orthogonal decomposition
fig,ax=plt.subplots(figsize=(5.4,3.65));ax.set(xlim=(-.2,3.35),ylim=(-.3,2.2));ax.axis('off')
ax.plot([0,3.22],[0,0],color=gray,lw=1.3);ax.plot([0,0],[0,2],color=gray,lw=1.3)
for x,y,col,label,tx,ty in [(2.25,1.42,copper,'Aday alan  v',2.03,1.72),(2.25,0,blue,'Fiziksel bileşen  Pv',1,-.23)]:
    ax.arrow(0,0,x,y,head_width=.10,head_length=.15,color=col,length_includes_head=True,width=.018);ax.text(tx,ty,label,color=col,ha='center',weight='bold')
ax.plot([2.25,2.25],[0,1.42],ls='--',color=gray);ax.text(2.31,.64,'Gradyan\nbileşeni',fontsize=11,va='center')
save(fig,'09_izdusum')
# Four checkpoints are separated deliberately rather than presented as a full run trace.
fig,ax=plt.subplots(figsize=(6.0,3.2));e=[0,9,24,49]
for y,col,label,m in [([.616,.349,.271,.224],blue,'Eğitim','o'),([.509,.343,.270,.231],copper,'Doğrulama','s')]:
    ax.plot(e,y,'--',lw=1.5,color=col,label=label,marker=m,markersize=7)
ax.set(xlabel='Eğitim dönemi (epoch)',ylabel='Altuzay kaybı',ylim=(.18,.68),xticks=e);ax.legend(frameon=False);ax.grid(axis='y',color=grid)
save(fig,'10_pilot')
# RF acceleration: normalized analytic voltage vs crossing phase.
fig,ax=plt.subplots(figsize=(5.6,3));delta=np.linspace(0,2*np.pi,240)
ax.plot(delta/np.pi,np.abs(np.sinc(delta/(2*np.pi))),color=blue,lw=3);ax.scatter([0,1,2],[1,2/np.pi,0],color=copper,zorder=8)
ax.set(xlabel=r'Parçacığın boşlukta gördüğü faz değişimi  $Deltaphi$',ylabel=r'$|V|/(E_0 L)$',xticks=[0,.5,1,1.5,2],xticklabels=['0','π/2','π','3π/2','2π'],ylim=(-.04,1.09));ax.grid(axis='y',color=grid)
save(fig,'11_gecis')
print('Figures rendered.')
