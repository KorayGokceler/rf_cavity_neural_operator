"""Sample CAD families and export oriented surface triangles for the talk."""
import numpy as np
import gmsh
from src.data_gen import cavity_shapes as cs
gmsh.initialize()
gmsh.option.setNumber("General.Terminal",0)
for name,fn,seed in [('elliptical',cs.build_elliptical,11),('reentrant',cs.build_reentrant,12),('spoke',cs.build_spoke,6),('ridged_box',cs.build_ridged_box,14)]:
    gmsh.model.add(name)
    rng=np.random.default_rng(seed)
    if name=='elliptical':fn(gmsh.model.occ,rng,n_cells=4,port_prob=0)
    else:fn(gmsh.model.occ,rng)
    gmsh.model.occ.synchronize()
    b=gmsh.model.getBoundingBox(-1,-1)
    width=max(np.array(b[3:])-b[:3])
    gmsh.option.setNumber('Mesh.MeshSizeMax',width/47)
    gmsh.option.setNumber('Mesh.MeshSizeMin',width/100)
    gmsh.model.mesh.generate(2)
    tags,pts,_=gmsh.model.mesh.getNodes()
    tags2,conn=gmsh.model.mesh.getElementsByType(2)
    order=np.argsort(tags)
    faces=order[np.searchsorted(tags[order],conn)].reshape(-1,3)
    np.savez_compressed('surface_'+name+'.npz',pts=pts.reshape(-1,3),faces=faces)
    print(name, len(faces),flush=True)
    gmsh.model.remove()
gmsh.finalize()
