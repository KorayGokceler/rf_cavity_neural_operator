"""Generate a numerical teaching example with the repository solver (SI units)."""
import json
from pathlib import Path
import numpy as np
from ngsolve import Mesh, SetNumThreads, curl
from netgen.occ import Cylinder, Pnt, Z, OCCGeometry
from scipy.constants import c
from scipy.special import jn_zeros
from src.data_gen.highorder import solve_modes
SetNumThreads(1)
radius, length = 0.10, 0.10
solid = Cylinder(Pnt(0,0,0), Z, r=radius, h=length)
solid.faces.name = 'wall'
mesh = Mesh(OCCGeometry(solid).GenerateMesh(maxh=0.036))
mesh.Curve(3)
sol = solve_modes(mesh, k=2, order=2)
gf = sol['gfs'][0]
n = 141
v = np.linspace(-radius*0.999, radius*0.999,n)
X,Y = np.meshgrid(v,v)
E=np.full_like(X,np.nan); B=E.copy()
for i,j in zip(*np.nonzero(X**2+Y**2 < (.993*radius)**2)):
    pos=mesh(float(X[i,j]),float(Y[i,j]),length/2)
    E[i,j]=gf(pos)[2]
    B[i,j]=np.linalg.norm(curl(gf)(pos))
E/=E[n//2,n//2]
B/=np.nanmax(B)
f=float(sol['f_hz'][0]); analytic=c*jn_zeros(0,1)[0]/(2*np.pi*radius)
np.savez('fe_section.npz',v=v,E=E,B=B)
Path('fe.json').write_text(json.dumps({'f_GHz':f/1e9,'analytic_GHz':analytic/1e9,'err_pct':100*(f/analytic-1),'tets':int(mesh.ne),'dofs':int(sol['info']['ndof']),'R_m':radius,'L_m':length},indent=2))
print(Path('fe.json').read_text())
